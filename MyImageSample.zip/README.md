# MyImageSample

This is a sample that get image from camera and gallery

you can read explain in my blog

https://black-jin0427.tistory.com/120
