package com.tistory.black_jin0427.myimagesample;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.gun0912.tedpermission.PermissionListener;
import com.gun0912.tedpermission.TedPermission;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    private Boolean isPermission = true;
    private ProgressBar progressBar;
    private Button loadButton;
    private int q;
    private Handler handler;
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        tedPermission();

        findViewById(R.id.loadButton).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Thread t = new Thread(new Runnable(){
                    @Override
                    public void run() {
                        for(q=0;q<=100;q++){
                            progressBar.setProgress(q);
                            Message msg = handler.obtainMessage();
                            msg.arg1 = q;
                            handler.sendMessage(msg);
                            try{
                                Thread.sleep(100);
                            }catch(InterruptedException e){
                                e.printStackTrace();
                            }
                        }
                    }
                });
                t.start();

            }
        });

        progressBar = (ProgressBar)findViewById(R.id.progressbar);
        handler = new Handler(){
            @Override
            public void handleMessage(Message msg) {
                if(msg.arg1 == 100){
                    Intent intent = new Intent(getApplicationContext(),GetImageActivity.class);
                    startActivity(intent);
                    finish();
                }
            }
        };



    }
    private void tedPermission() {

        PermissionListener permissionListener = new PermissionListener() {
            @Override
            public void onPermissionGranted() {
                // 권한 요청 성공
                isPermission = true;

            }

            @Override
            public void onPermissionDenied(ArrayList<String> deniedPermissions) {
                // 권한 요청 실패
                isPermission = false;
            }
        };
        TedPermission.with(this)
                .setPermissionListener(permissionListener)
                .setRationaleMessage(getResources().getString(R.string.permission_2))
                .setDeniedMessage(getResources().getString(R.string.permission_1))
                .setPermissions(Manifest.permission.WRITE_EXTERNAL_STORAGE, Manifest.permission.CAMERA)
                .check();
    }

    private void goToActivity(Class activityClass) {
        if(isPermission) {
            Intent intent = new Intent(this, activityClass);
            startActivity(intent);
        } else {
            Toast.makeText(this, getResources().getString(R.string.permission_2), Toast.LENGTH_LONG).show();
        }

    }
}
